import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createPipeline, fromWire, toWire } from '../src/index.mjs';
import { adapterFromEnv } from './llm_env.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const rows=fs.readFileSync(path.join(here,'data/semantic_cases.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
const formalizer=adapterFromEnv('FORMALIZER');
const judge=adapterFromEnv('JUDGE','FORMALIZER');
const pipeline=createPipeline({formalizer,judge,maxRepairs:Number(process.env.MAX_REPAIRS??1),threshold:Number(process.env.JUDGE_THRESHOLD??0.985)});

const results=[]; let accepted=0, exact=0; let scoreSum=0;
for(const r of rows){
  try{
    const out=await pipeline.run(r.text);
    const gold=toWire(fromWire(r.goldWire));
    const isExact=out.best.wire===gold;
    if(isExact) exact++;
    if(out.accepted) accepted++;
    scoreSum+=out.best.audit.score;
    results.push({id:r.id,tags:r.tags,accepted:out.accepted,score:out.best.audit.score,exactGold:isExact,iteration:out.best.iteration,wire:out.best.wire,goldWire:gold,diff:out.best.audit});
    console.log(`${r.id}: score=${out.best.audit.score.toFixed(3)} accepted=${out.accepted} exact=${isExact} repair=${out.best.iteration}`);
  }catch(e){
    results.push({id:r.id,error:String(e?.message??e)});
    console.log(`${r.id}: ERROR ${e?.message??e}`);
  }
}
const ok=results.filter(x=>!x.error).length;
const report={cases:rows.length,completed:ok,acceptedRate:accepted/rows.length,exactGoldRate:exact/rows.length,meanJudgeScore:ok?scoreSum/ok:0,results};
fs.writeFileSync(path.join(here,'..','reports','formalizer-eval.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({cases:report.cases,completed:report.completed,acceptedRate:report.acceptedRate,exactGoldRate:report.exactGoldRate,meanJudgeScore:report.meanJudgeScore},null,2));
