import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { fromWire, toWire, isVar, isDocument } from '../src/index.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const rows = fs.readFileSync(path.join(here,'data/semantic_cases.jsonl'),'utf8').trim().split('\n').map(JSON.parse);

function verboseAst(ir) {
  const vars = new Map(); let n = 0;
  const vn = v => { if (!vars.has(v)) vars.set(v, `v${n++}`); return vars.get(v); };
  const cv = x => {
    if (isVar(x)) return { type:'variable', name:vn(x) };
    if (!Array.isArray(x)) return { type:'constant', value:x };
    if (isDocument(x)) return { type:'document', items:x.map(cv) };
    const op=x[0];
    if (op==='$') return { type:'predicate', name:x[1], arguments:x.slice(2).map(cv) };
    if (['U','E','W'].includes(op)) return { type:{U:'forall',E:'exists',W:'wh_question'}[op], variable:vn(x[1]), body:cv(x[2]) };
    return { type:{A:'and',O:'or',N:'not',I:'implies',Q:'yes_no_question'}[op], arguments:x.slice(1).map(cv) };
  };
  return JSON.stringify(cv(ir));
}

let wire=0, verbose=0;
const perCase=[];
for (const row of rows) {
  const ir=fromWire(row.goldWire);
  const w=toWire(ir), v=verboseAst(ir);
  wire += w.length; verbose += v.length;
  perCase.push({ id:row.id, wireChars:w.length, verboseJsonChars:v.length, ratio:+(w.length/v.length).toFixed(3) });
}
const report={
  cases:rows.length,
  wireChars:wire,
  verboseJsonChars:verbose,
  wireVsVerboseRatio:+(wire/verbose).toFixed(3),
  reductionPercent:+((1-wire/verbose)*100).toFixed(1),
  note:'Character count is only a tokenizer-independent proxy; measure real tokens with the target model tokenizer.',
  perCase
};
const out=path.join(here,'..','reports','compactness-eval.json');
fs.writeFileSync(out,JSON.stringify(report,null,2));
console.log(JSON.stringify({...report,perCase:undefined},null,2));
