#!/usr/bin/env node
/**
 * Dependency-free regression evaluator.
 * It intentionally measures only surface/structural agreement with a gold file.
 * Semantic equivalence must be scored separately using docs/semantic-eval.md.
 */
import fs from 'node:fs';
import { canonicalizeCNL, validateCNL } from './cnl-core.mjs';

function readJsonl(path) {
  return fs.readFileSync(path, 'utf8')
    .split(/\r?\n/)
    .map(x => x.trim())
    .filter(Boolean)
    .map((line, i) => {
      try { return JSON.parse(line); }
      catch (e) { throw new Error(`${path}:${i + 1}: ${e.message}`); }
    });
}

function usage() {
  console.log(`Usage:
  node eval.mjs --gold examples/regression.jsonl --pred predictions.jsonl

Prediction JSONL format:
  {"id":"a01","output":"ASSERT: ..."}
`);
  process.exit(1);
}

const args = process.argv.slice(2);
const goldPath = args[args.indexOf('--gold') + 1];
const predPath = args[args.indexOf('--pred') + 1];
if (!goldPath || !predPath || args.indexOf('--gold') < 0 || args.indexOf('--pred') < 0) usage();

const gold = readJsonl(goldPath);
const preds = readJsonl(predPath);
const predMap = new Map(preds.map(x => [x.id, x]));

let exact = 0;
let valid = 0;
let missing = 0;
const failures = [];

for (const g of gold) {
  const p = predMap.get(g.id);
  if (!p) {
    missing++;
    failures.push({ id: g.id, reason: 'missing prediction' });
    continue;
  }
  const v = validateCNL(p.output);
  if (v.ok) valid++;
  const gc = canonicalizeCNL(g.gold);
  const pc = canonicalizeCNL(p.output);
  if (gc === pc) exact++;
  else failures.push({ id: g.id, reason: 'not exact', gold: gc, pred: pc, valid: v.ok });
}

const n = gold.length;
const report = {
  records: n,
  predictions: preds.length,
  validFormat: valid,
  validFormatRate: n ? valid / n : 0,
  exact: exact,
  exactRate: n ? exact / n : 0,
  missing,
  note: 'Exact match is a regression metric, not a semantic-equivalence metric.',
  failures
};
console.log(JSON.stringify(report, null, 2));
process.exitCode = missing ? 2 : 0;
