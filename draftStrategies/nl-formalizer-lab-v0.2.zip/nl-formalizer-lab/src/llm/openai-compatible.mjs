import {extractJsonObject} from "../util.mjs";

export class OpenAICompatibleClient {
  constructor({
    baseURL = process.env.LLM_BASE_URL ?? "http://127.0.0.1:8000/v1",
    apiKey = process.env.LLM_API_KEY ?? "",
    model = process.env.LLM_MODEL ?? "",
    temperature = 0,
    timeoutMs = 120000,
    extraBody = {}
  } = {}) {
    if (!model) throw new Error("LLM model is required (pass model or set LLM_MODEL)");
    this.baseURL = baseURL.replace(/\/$/, "");
    this.apiKey = apiKey;
    this.model = model;
    this.temperature = temperature;
    this.timeoutMs = timeoutMs;
    this.extraBody = extraBody;
  }

  async completeDetailed({system, user, temperature = this.temperature}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    const started = performance.now();
    try {
      const headers = {"content-type": "application/json"};
      if (this.apiKey) headers.authorization = `Bearer ${this.apiKey}`;
      const res = await fetch(`${this.baseURL}/chat/completions`, {
        method: "POST",
        headers,
        signal: controller.signal,
        body: JSON.stringify({
          model: this.model,
          temperature,
          stream: false,
          messages: [
            ...(system ? [{role: "system", content: system}] : []),
            {role: "user", content: user}
          ],
          ...this.extraBody
        })
      });
      if (!res.ok) throw new Error(`LLM HTTP ${res.status}: ${await res.text()}`);
      const data = await res.json();
      const content = data?.choices?.[0]?.message?.content;
      if (typeof content !== "string") throw new Error("LLM response had no message content");
      const detail = {
        content,
        model: data.model ?? this.model,
        usage: data.usage ?? null,
        requestId: data.id ?? null,
        latencyMs: performance.now() - started
      };
      this.lastResponseMeta = {...detail, content: undefined};
      return detail;
    } finally {
      clearTimeout(timer);
    }
  }

  async complete(messages) {
    return (await this.completeDetailed(messages)).content;
  }

  async completeJSON(messages) {
    return extractJsonObject(await this.complete(messages));
  }
}

export function clientFromEnv({prefix = "LLM", model} = {}) {
  return new OpenAICompatibleClient({
    baseURL: process.env[`${prefix}_BASE_URL`] ?? process.env.LLM_BASE_URL,
    apiKey: process.env[`${prefix}_API_KEY`] ?? process.env.LLM_API_KEY,
    model: model ?? process.env[`${prefix}_MODEL`] ?? process.env.LLM_MODEL
  });
}
