#!/usr/bin/env node
import fs from 'node:fs';
import {
  VERSION,
  buildFormalizationPrompt,
  canonicalizeCNL,
  inspectOutput,
  parseCNL,
  validateCNL
} from './cnl-core.mjs';

function usage(exitCode = 0) {
  console.log(`CNL-Core v${VERSION}

Usage:
  node cli.mjs prompt [file|-]
  node cli.mjs validate [file|-]
  node cli.mjs parse [file|-]
  node cli.mjs canonicalize [file|-]
  node cli.mjs inspect [file|-]

Examples:
  echo "Could you run the test?" | node cli.mjs prompt -
  node cli.mjs validate examples/sample-output.cnl
`);
  process.exit(exitCode);
}

function readInput(name) {
  if (!name || name === '-') return fs.readFileSync(0, 'utf8');
  return fs.readFileSync(name, 'utf8');
}

const [command, file] = process.argv.slice(2);
if (!command || command === '-h' || command === '--help') usage(0);

const input = readInput(file);

switch (command) {
  case 'prompt':
    process.stdout.write(buildFormalizationPrompt(input) + '\n');
    break;
  case 'validate': {
    const r = validateCNL(input);
    console.log(JSON.stringify(r, null, 2));
    process.exitCode = r.ok ? 0 : 1;
    break;
  }
  case 'parse':
    console.log(JSON.stringify(parseCNL(input), null, 2));
    break;
  case 'canonicalize':
    process.stdout.write(canonicalizeCNL(input) + '\n');
    break;
  case 'inspect':
    console.log(JSON.stringify(inspectOutput(input), null, 2));
    break;
  default:
    usage(1);
}
