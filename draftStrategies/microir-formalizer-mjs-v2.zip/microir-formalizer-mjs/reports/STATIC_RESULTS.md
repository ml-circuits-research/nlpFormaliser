# Static results

These results were executed locally with Node.js 22. They do **not** use or claim any LLM semantic accuracy.

- Benchmark cases: **30**
- Parsed/validated: **30/30**
- Exact wire parse/serialize round-trip: **30/30**
- Deterministic CNL generated: **30/30**
- Mean wire size: **164.9 characters**
- Mean readable CNL size: **641.1 characters**
- Mean compact judge-CNL size: **313 characters**
- Wire vs verbose JSON AST character reduction: **83.8%**

Character counts are a tokenizer-independent proxy, not actual model token counts. Token counts must be measured with the tokenizer of the formalizer/judge being evaluated.

LLM-dependent scripts (`eval:judge`, `eval:formalizer`) are intentionally not reported until a real endpoint/model is configured.
