def atom(pred, *args, neg=False):
    return {"pred": pred, "args": list(args), "neg": neg}

def rule(head, *body):
    return {"head": head, "body": list(body)}

def make_ir(facts=None, rules=None):
    return {"facts": facts or [], "rules": rules or []}

def atom_key(a):
    return (a.get("neg", False), a["pred"], tuple(a["args"]))

def is_var(x):
    return isinstance(x, str) and x.startswith("?")

def unify_atom(pattern, fact, env):
    if pattern["pred"] != fact["pred"] or pattern.get("neg",False) != fact.get("neg",False):
        return None
    if len(pattern["args"]) != len(fact["args"]):
        return None
    env = dict(env)
    for p, f in zip(pattern["args"], fact["args"]):
        if is_var(p):
            if p in env and env[p] != f:
                return None
            env[p] = f
        elif p != f:
            return None
    return env

def subst_atom(a, env):
    return {
        "pred": a["pred"],
        "args": [env.get(x,x) if is_var(x) else x for x in a["args"]],
        "neg": a.get("neg",False),
    }

def closure(ir, max_rounds=50):
    facts = {atom_key(f): f for f in ir.get("facts",[])}
    for _ in range(max_rounds):
        added = 0
        fact_list = list(facts.values())
        for r in ir.get("rules",[]):
            envs = [dict()]
            for b in r["body"]:
                new_envs = []
                for env in envs:
                    for f in fact_list:
                        ue = unify_atom(subst_atom(b, env), f, env)
                        if ue is not None:
                            new_envs.append(ue)
                envs = new_envs
                if not envs:
                    break
            for env in envs:
                h = subst_atom(r["head"], env)
                if any(is_var(x) for x in h["args"]):
                    continue
                k = atom_key(h)
                if k not in facts:
                    facts[k] = h
                    added += 1
        if not added:
            break
    return list(facts.values())

def query_status(ir, q):
    ks = {atom_key(f) for f in closure(ir)}
    if atom_key(q) in ks:
        return "TRUE"
    opp = dict(q)
    opp["neg"] = not q.get("neg",False)
    if atom_key(opp) in ks:
        return "FALSE"
    return "UNKNOWN"
