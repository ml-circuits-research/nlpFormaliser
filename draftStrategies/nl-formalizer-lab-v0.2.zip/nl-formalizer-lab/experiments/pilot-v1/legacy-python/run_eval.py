import json
from pathlib import Path
from reasoner import query_status

ROOT = Path(__file__).parent

def eval_set(benchmark_name, ir_name):
    benchmark = json.loads((ROOT/benchmark_name).read_text())
    irs = json.loads((ROOT/ir_name).read_text())
    total = sem_total = ctrl_total = 0
    ok = sem_ok = ctrl_ok = 0
    for c in benchmark:
        ir = irs[c["id"]]
        for t in c["tests"]:
            got = query_status(ir, t["query"])
            hit = got == t["expected"]
            total += 1; ok += int(hit)
            if t.get("kind") == "control":
                ctrl_total += 1; ctrl_ok += int(hit)
            else:
                sem_total += 1; sem_ok += int(hit)
    return {
        "overall": ok/total if total else 0,
        "semantic": sem_ok/sem_total if sem_total else 0,
        "control": ctrl_ok/ctrl_total if ctrl_total else 0,
        "n": total,
    }

if __name__ == "__main__":
    print("development-v1", eval_set("benchmark_development.json","drafts_development_v1.json"))
    print("development-v2", eval_set("benchmark_development.json","drafts_development_v2.json"))
    print("heldout-heuristic", eval_set("benchmark_heldout.json","drafts_heldout_v2.json"))
    print("heldout-repair", eval_set("benchmark_heldout.json","repairs_heldout.json"))
