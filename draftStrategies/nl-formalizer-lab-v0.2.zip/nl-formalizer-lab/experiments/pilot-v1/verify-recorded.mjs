import fs from "node:fs/promises";
import {behaviorMetrics, reuseMetrics} from "../../src/index.mjs";

const root = new URL("./legacy-python/", import.meta.url);
const benchmark = JSON.parse(await fs.readFile(new URL("benchmark_heldout.json", root), "utf8"));
const repairs = JSON.parse(await fs.readFile(new URL("repairs_heldout.json", root), "utf8"));
const drafts = JSON.parse(await fs.readFile(new URL("drafts_heldout_v2.json", root), "utf8"));

let passed = 0, total = 0;
const reuse = [];
let retainedTotal = 0, finalItemsTotal = 0;
for (const sample of benchmark) {
  const b = behaviorMetrics(repairs[sample.id], sample.tests ?? []);
  passed += b.rows.filter((x) => x.pass).length;
  total += b.rows.length;
  const rm = reuseMetrics(drafts[sample.id], repairs[sample.id]);
  reuse.push(rm.finalReuse);
  retainedTotal += rm.retained;
  finalItemsTotal += rm.finalItems;
}
const mean = (xs) => xs.reduce((a,b)=>a+b,0)/(xs.length||1);
const result = {
  cases: benchmark.length, tests: total, behaviorAccuracy: passed/total,
  aggregateFinalReuse: finalItemsTotal ? retainedTotal/finalItemsTotal : 1,
  meanPerCaseFinalReuse: mean(reuse)
};
console.log(JSON.stringify(result, null, 2));
if (result.behaviorAccuracy !== 1) process.exitCode = 1;
