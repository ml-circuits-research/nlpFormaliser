import { createOpenAICompatibleAdapter, createPipeline } from '../src/index.mjs';

const formalizer = createOpenAICompatibleAdapter({
  baseURL: process.env.FORMALIZER_BASE_URL,
  model: process.env.FORMALIZER_MODEL,
  apiKey: process.env.FORMALIZER_API_KEY || ''
});

const judge = createOpenAICompatibleAdapter({
  baseURL: process.env.JUDGE_BASE_URL || process.env.FORMALIZER_BASE_URL,
  model: process.env.JUDGE_MODEL || process.env.FORMALIZER_MODEL,
  apiKey: process.env.JUDGE_API_KEY || process.env.FORMALIZER_API_KEY || ''
});

const pipeline = createPipeline({ formalizer, judge, maxRepairs:1, threshold:.985 });
const text = 'Alice did not promise to attend. Bob believes she promised not to attend. Did Alice promise to attend?';
console.log(JSON.stringify(await pipeline.run(text), null, 2));
