#!/usr/bin/env node
import fs from 'node:fs';
import process from 'node:process';
import {
  formalizeConversation,
  formalizeText,
  buildJudgeBatches,
  makeOpenAICompatibleCaller,
  judgeBatches,
  combineValidation,
} from './src/index.mjs';

function usage(code=0) {
  console.log(`nl2cnl-judge-strategy

Commands:
  formalize TEXT
  formalize --file input.txt
  conversation turns.json
  judge-request turns.json [--policy all|risky|sampled]
  judge-live turns.json [--policy all|risky|sampled]

turns.json format:
  [{"id":"t1","speaker":"user","text":"..."}, ...]

judge-live environment:
  NLCNL_ENDPOINT   full OpenAI-compatible /v1/chat/completions URL
  NLCNL_MODEL      model name
  NLCNL_API_KEY    optional bearer token

Examples:
  node cli.mjs formalize "Every reviewer must return a report."
  node cli.mjs conversation examples/connected-chat.json
  node cli.mjs judge-request examples/connected-chat.json --policy all
  NLCNL_ENDPOINT=http://127.0.0.1:8000/v1/chat/completions \\
  NLCNL_MODEL=qwen node cli.mjs judge-live examples/connected-chat.json --policy sampled
`);
  process.exit(code);
}

function argValue(args, name, fallback=null) {
  const i=args.indexOf(name); return i>=0 ? args[i+1] : fallback;
}
function readJson(path){ return JSON.parse(fs.readFileSync(path,'utf8')); }
function write(obj){ process.stdout.write(JSON.stringify(obj,null,2)+'\n'); }

const args=process.argv.slice(2); const cmd=args.shift();
if(!cmd||cmd==='-h'||cmd==='--help') usage(0);

if(cmd==='formalize'){
  const fp=argValue(args,'--file');
  const text=fp?fs.readFileSync(fp,'utf8'):args.filter(x=>x!=='--file'&&x!==fp).join(' ');
  if(!text.trim()) usage(2);
  const out=formalizeText(text);
  write(out);
}else if(cmd==='conversation'){
  const fp=args[0]; if(!fp) usage(2); write(formalizeConversation(readJson(fp)));
}else if(cmd==='judge-request'){
  const fp=args[0]; if(!fp) usage(2);
  const policy=argValue(args,'--policy','sampled');
  const formalized=formalizeConversation(readJson(fp));
  write({formalized,batches:buildJudgeBatches(formalized,{policy})});
}else if(cmd==='judge-live'){
  const fp=args[0]; if(!fp) usage(2);
  const policy=argValue(args,'--policy','sampled');
  const endpoint=process.env.NLCNL_ENDPOINT, model=process.env.NLCNL_MODEL, apiKey=process.env.NLCNL_API_KEY||null;
  if(!endpoint||!model) throw new Error('NLCNL_ENDPOINT and NLCNL_MODEL are required');
  const formalized=formalizeConversation(readJson(fp));
  const batches=buildJudgeBatches(formalized,{policy});
  const callLLM=makeOpenAICompatibleCaller({endpoint,model,apiKey});
  const responses=await judgeBatches(batches,{callLLM});
  write({formalized,batches,responses,validated:combineValidation(formalized,responses,{requireJudgeForAcceptance:policy==='all'})});
}else usage(2);
