// Zero-dependency adapter for OpenAI-compatible chat-completions endpoints.
// Works with many local servers (vLLM, llama.cpp server, LM Studio, etc.) when they expose this API shape.

export function createOpenAICompatibleAdapter({
  baseURL,
  model,
  apiKey = '',
  temperature = 0,
  maxTokens = 2048,
  extra = {}
}) {
  if (!baseURL || !model) throw new TypeError('baseURL and model are required');
  const url = `${baseURL.replace(/\/$/, '')}/chat/completions`;

  return async ({ system, user }) => {
    const headers = { 'content-type': 'application/json' };
    if (apiKey) headers.authorization = `Bearer ${apiKey}`;
    const body = {
      model,
      temperature,
      max_tokens: maxTokens,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user }
      ],
      ...extra
    };
    const r = await fetch(url, { method:'POST', headers, body:JSON.stringify(body) });
    if (!r.ok) throw new Error(`LLM HTTP ${r.status}: ${await r.text()}`);
    const j = await r.json();
    const content = j?.choices?.[0]?.message?.content;
    if (typeof content !== 'string') throw new Error('Unexpected chat-completions response');
    return content;
  };
}
