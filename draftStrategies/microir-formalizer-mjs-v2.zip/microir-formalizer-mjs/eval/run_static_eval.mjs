import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { fromWire, toWire, toCNL, validate, stats } from '../src/index.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const dataset = path.join(here, 'data/semantic_cases.jsonl');
const outPath = path.join(here, '..', 'reports', 'static-eval.json');
const rows = fs.readFileSync(dataset, 'utf8').trim().split('\n').map(JSON.parse);

let parsed = 0, roundTrip = 0, cnl = 0;
const failures = [];
let nodes = 0, predicates = 0, wireChars = 0, cnlChars = 0, compactCnlChars = 0;

for (const row of rows) {
  try {
    const ir = fromWire(row.goldWire);
    parsed++;
    const check = validate(ir);
    if (!check.ok) throw new Error(check.errors.join('; '));
    const w = toWire(ir);
    if (w === row.goldWire) roundTrip++;
    else failures.push({ id:row.id, stage:'roundtrip', expected:row.goldWire, got:w });
    const c = toCNL(ir);
    const cc = toCNL(ir,{compact:true});
    if (c.length > 0 && cc.length > 0) cnl++;
    const s = stats(ir);
    nodes += s.nodes;
    predicates += Object.values(s.predicates).reduce((a,b)=>a+b,0);
    wireChars += w.length;
    cnlChars += c.length;
    compactCnlChars += cc.length;
  } catch (e) {
    failures.push({ id:row.id, stage:'parse', error:String(e?.message ?? e) });
  }
}

const report = {
  dataset: path.basename(dataset),
  cases: rows.length,
  parsed,
  exactWireRoundTrip: roundTrip,
  cnlGenerated: cnl,
  averages: {
    irNodes: +(nodes / rows.length).toFixed(2),
    predicateOccurrences: +(predicates / rows.length).toFixed(2),
    wireChars: +(wireChars / rows.length).toFixed(1),
    cnlChars: +(cnlChars / rows.length).toFixed(1),
    compactJudgeCnlChars: +(compactCnlChars / rows.length).toFixed(1)
  },
  failures
};
fs.writeFileSync(outPath, JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
process.exit(failures.length ? 1 : 0);
