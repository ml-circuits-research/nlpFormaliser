# Offline diagnostic baseline

This file is a smoke-test of the package, not an accuracy benchmark.

Input: `examples/connected-chat.json` (30 linked turns).

With the current symbolic engine and `policy: sampled, safeSampleRate: 0.20`:

- 30 source turns are formalized;
- 27 turns are selected for semantic LLM review;
- all 27 fit in one judge batch under the default batch limits;
- the symbolic audit reports hard failures on 14 turns.

Interpretation: the present symbolic front end is deliberately conservative and still weak on complex conversational language. The research hypothesis being tested is whether a single batched semantic judge can cheaply distinguish adequate candidates from bad ones, allowing this strategy to compete with more model-heavy formalizers.

Do not treat symbolic audit pass/fail as ground-truth semantic accuracy.
