import re

def slug(s):
    s=s.strip().lower()
    s=s.replace("0°c","zero_c").replace("0 °c","zero_c")
    s=re.sub(r"^(the|a|an)\s+","",s)
    s=re.sub(r"[^a-z0-9_]+","_",s)
    return s.strip("_")


def atom(pred, *args, neg=False):
    return {"pred": pred, "args": list(args), "neg": neg}


def rule(head, *body):
    return {"head": head, "body": list(body)}


def make_ir(facts=None, rules=None):
    return {"facts": facts or [], "rules": rules or []}


def atom_key(a):
    return (a.get("neg", False), a["pred"], tuple(a["args"]))


verb_map = {'owns': 'owns', 'own': 'owns', 'owned': 'owns', 'deleted': 'deleted', 'delete': 'deleted', 'authored': 'authored', 'author': 'authored', 'entered': 'entered', 'enter': 'entered', 'failed': 'failed', 'fail': 'failed', 'reviewed': 'reviewed', 'review': 'reviewed', 'holding': 'holding', 'holds': 'holding', 'hold': 'holding', 'detects': 'detects', 'detect': 'detects', 'speeds up': 'speeds_up', 'speed up': 'speeds_up', 'lost': 'lost', 'approved': 'approved', 'approve': 'approved', 'sent': 'sent', 'send': 'sent', 'promised': 'promised', 'promise': 'promised', 'submit': 'submit', 'submitted': 'submit', 'switched off': 'switched_off', 'switch off': 'switched_off', 'belongs to': 'belongs_to'}

def addfact(ir, p, *args, neg=False):
    f=atom(p,*[slug(a) if isinstance(a,str) and not a.startswith("?") else a for a in args],neg=neg)
    if atom_key(f) not in {atom_key(x) for x in ir["facts"]}:
        ir["facts"].append(f)


def heuristic_parse(text):
    ir=make_ir()
    t=text.strip()
    # split, retaining semicolon clauses
    clauses=[c.strip() for c in re.split(r"(?<=[.!?])\s+|;\s*",t) if c.strip()]
    # global generic patterns first
    low=t.lower()

    # EVERY ... WHO ... CAN ...
    m=re.search(r"every\s+([a-z_ ]+?)\s+who\s+owns\s+a\s+([a-z_ ]+?)\s+can\s+run\s+a\s+([a-z_ ]+?)(?:\.|$)",low)
    if m:
        typ=slug(m.group(1)); objtyp=slug(m.group(2)); target=slug(m.group(3))
        ir["rules"].append(rule(atom("can_run","?x",target),
                                atom(typ,"?x"),atom("owns","?x","?g"),atom(objtyp,"?g")))
    # NO reviewer may approve a paper they authored
    m=re.search(r"no\s+([a-z_]+)\s+may\s+([a-z_]+)\s+a\s+([a-z_]+)\s+they\s+([a-z_]+)",low)
    if m:
        typ, act, objtyp, rel = map(slug,m.groups())
        ir["rules"].append(rule(atom(f"prohibited_{act}","?x","?p"),
                                atom(typ,"?x"),atom(rel,"?x","?p")))
    # ONLY administrators can delete accounts
    m=re.search(r"only\s+([a-z_]+)\s+can\s+([a-z_]+)\s+([a-z_]+)",low)
    if m:
        typ, act, objtyp = map(slug,m.groups())
        ir["rules"].append(rule(atom(typ.rstrip("s"),"?x"),
                                atom(verb_map.get(act,act),"?x","?a"),atom(objtyp.rstrip("s"),"?a")))
    # unless backup succeeds, deployment must not start
    m=re.search(r"unless\s+the\s+([a-z_]+)\s+([a-z_]+),\s*([a-z_]+)\s+must\s+not\s+([a-z_]+)",low)
    if m:
        subj, v, out, act = map(slug,m.groups())
        ir["rules"].append(rule(atom(f"prohibited_{act}",out),atom(v,subj,neg=True)))
    # considered stale when checksum differs
    m=re.search(r"a\s+([a-z_]+)\s+is\s+considered\s+([a-z_]+)\s+when\s+its\s+([a-z_]+)\s+differs",low)
    if m:
        typ,prop,thing=map(slug,m.groups())
        ir["rules"].append(rule(atom(prop,"?x"),atom(typ,"?x"),atom(f"{thing}_differs","?x")))
    # may pick ... only if its gripper is empty
    m=re.search(r"(?:robot\s+)?([a-z0-9_]+)\s+may\s+pick\s+up\s+(?:box\s+)?([a-z0-9_]+)\s+only\s+if\s+its\s+gripper\s+is\s+empty",low)
    if m:
        # heuristic overgeneralizes rule over robot variable
        r,b=map(slug,m.groups())
        ir["rules"].append(rule(atom("gripper_empty",r),atom("may_pick",r,b)))
    # if temp below -> water can freeze
    if re.search(r"if\s+the\s+temperature\s+drops\s+below\s+0°c,\s*water\s+can\s+freeze",low):
        ir["rules"].append(rule(atom("can_freeze","water"),atom("below","temperature","zero_c")))
    # either-or smoke
    if re.search(r"if\s+either\s+sensor\s+a\s+or\s+sensor\s+b\s+detects\s+smoke,\s*the\s+alarm\s+sounds",low):
        ir["rules"].append(rule(atom("alarm_sounds"),atom("detects_smoke","sensor_a")))
        ir["rules"].append(rule(atom("alarm_sounds"),atom("detects_smoke","sensor_b")))
    # generic if overloaded
    if re.search(r"if\s+a\s+server\s+is\s+overloaded,\s*the\s+scheduler\s+moves\s+new\s+jobs\s+elsewhere",low):
        ir["rules"].append(rule(atom("moves","scheduler","new_jobs","elsewhere"),atom("server","?s"),atom("overloaded","?s")))
    # public status requests do not [require auth]
    if "public status requests do not" in low and "requires authentication" in low:
        ir["rules"].append(rule(atom("requires_auth","?x",neg=True),atom("public_status_request","?x")))

    for clause in clauses:
        c=clause.strip().rstrip(".!?")
        cl=c.lower().strip()

        # named noun entity: "Sensor S1", "Catalyst C7", "reaction R2", "Device D1", "Robot R1", "box B"
        for typ, ent in re.findall(r"\b(sensor|catalyst|reaction|device|robot|box|file|sample|node|gpu)\s+([A-Za-z]*\d+|[A-Z])\b", c, flags=re.I):
            addfact(ir, slug(typ), ent)

        # X is a/an TYPE; allows "Mira is a physicist", "Node7 is a server", R17...
        for m in re.finditer(r"\b([A-Za-z][A-Za-z0-9]*)\s+is\s+(?:a|an)\s+([a-z][a-z_ ]*?)(?=\s+and\b|\s*,|\s+which\b|$)", c, flags=re.I):
            ent, typ=m.groups()
            addfact(ir, slug(typ), ent)

        # entity is property
        m=re.match(r"(?:the\s+)?([A-Za-z][A-Za-z0-9]*)\s+is\s+(red|clean|contaminated|overloaded)\b", c, flags=re.I)
        if m:
            ent,prop=m.groups(); addfact(ir,slug(prop),ent)

        # "Sample3 is clean, while sample4 is contaminated"
        for ent,prop in re.findall(r"\b([A-Za-z]+\d+)\s+is\s+(clean|contaminated|overloaded)\b",c,flags=re.I):
            addfact(ir,slug(prop),ent)

        # "and is overloaded" with prior subject
        m=re.match(r"([A-Za-z][A-Za-z0-9]*)\s+is\s+(?:a|an)\s+\w+\s+and\s+is\s+(overloaded)",c,flags=re.I)
        if m:
            addfact(ir,slug(m.group(2)),m.group(1))

        # explicit below
        if re.search(r"the temperature is below 0°c",cl):
            addfact(ir,"below","temperature","zero_c")

        # mounted on
        m=re.search(r"(?:sensor\s+)?([A-Za-z0-9]+)\s+is\s+red\s+and\s+is\s+mounted\s+on\s+the\s+(.+)$",c,flags=re.I)
        if m:
            ent,loc=m.groups(); addfact(ir,"red",ent); addfact(ir,"mounted_on",ent,loc)

        # west of pair(s)
        for a,b in re.findall(r"\b([A-Z][a-z]+)\s+is\s+west\s+of\s+([A-Z][a-z]+)",c):
            addfact(ir,"west_of",a,b)

        # belongs to
        m=re.search(r"(?:the\s+)?([a-zA-Z0-9_]+)\s+belongs\s+to\s+([A-Z][a-z]+)",c)
        if m: addfact(ir,"belongs_to",m.group(1),m.group(2))
        # holding
        m=re.search(r"([A-Z][a-z]+)\s+is\s+holding\s+([a-zA-Z0-9_]+)",c)
        if m: addfact(ir,"holding",m.group(1),m.group(2))

        # simple owns, incl "She owns a workstation", "Ana ... owns GPU1"
        for m in re.finditer(r"\b([A-Z][A-Za-z0-9]*|She|He|They)\s+(?:is\s+a\s+\w+\s+and\s+)?owns\s+(?:a\s+)?([A-Za-z0-9]+)",c):
            addfact(ir,"owns",m.group(1),m.group(2))

        # authored/deleted
        for v in ["authored","deleted","reviewed"]:
            m=re.search(rf"\b([A-Z][A-Za-z0-9]*)\s+(?:is\s+a\s+\w+\s+and\s+)?{v}\s+([A-Za-z0-9]+)",c)
            if m: addfact(ir,v,m.group(1),m.group(2))

        # did not succeed
        m=re.search(r"(?:the\s+)?([a-zA-Z0-9_]+)\s+did\s+not\s+([a-z_]+)",c,flags=re.I)
        if m: addfact(ir,slug(m.group(2)),m.group(1),neg=True)

        # checksum differs
        m=re.search(r"([A-Za-z0-9]+)\s+is\s+a\s+file\s+and\s+its\s+checksum\s+differs",c,flags=re.I)
        if m:
            addfact(ir,"file",m.group(1)); addfact(ir,"checksum_differs",m.group(1))

        # permitted to pick
        m=re.search(r"([A-Za-z0-9]+)\s+is\s+permitted\s+to\s+pick\s+up\s+([A-Za-z0-9]+)",c,flags=re.I)
        if m: addfact(ir,"may_pick",m.group(1),m.group(2))

        # detects smoke
        m=re.search(r"(sensor\s+[AB])\s+detects\s+smoke",c,flags=re.I)
        if m: addfact(ir,"detects_smoke",m.group(1).replace(" ","_"))

        # send ditransitive
        m=re.search(r"([A-Z][a-z]+)\s+sent\s+([A-Z][a-z]+)\s+the\s+([a-z]+)\s+on\s+([A-Z][a-z]+)",c)
        if m:
            s,r,o,tm=m.groups(); addfact(ir,"sent",s,r,o); addfact(ir,"sent_on",s,o,tm)

        # passive approved
        m=re.search(r"the\s+([a-z]+)\s+was\s+approved\s+by\s+([A-Z][a-z]+)",c)
        if m:
            o,s=m.groups(); addfact(ir,"approved",s,o)

        # catalyst pattern
        m=re.search(r"catalyst\s+([A-Za-z0-9]+)\s+speeds\s+up\s+reaction\s+([A-Za-z0-9]+)",c,flags=re.I)
        if m:
            a,b=m.groups(); addfact(ir,"speeds_up",a,b)

        # experiment failed because pump lost power
        m=re.search(r"the\s+([a-z]+)\s+failed\s+because\s+the\s+([a-z]+)\s+lost\s+power",c,flags=re.I)
        if m:
            x,y=m.groups(); addfact(ir,"failed",x); addfact(ir,"lost_power",y)

        # promise rough: doesn't resolve she
        m=re.search(r"([A-Z][a-z]+)\s+promised\s+([A-Z][a-z]+)\s+that\s+(she|he)\s+would\s+submit\s+the\s+([a-z]+)",c)
        if m:
            a,b,pro,o=m.groups()
            addfact(ir,"promised",a,b,"submit_"+slug(o))
            addfact(ir,"will_submit",pro,o)

        # device calibration
        m=re.search(r"device\s+([A-Za-z0-9]+)\s+must\s+be\s+calibrated\s+before\s+it\s+is\s+used",c,flags=re.I)
        if m: addfact(ir,"requires_calibration_before_use",m.group(1))

        # entered ... then he switched off
        m=re.search(r"([A-Z][a-z]+)\s+entered\s+the\s+([a-z]+),\s*then\s+(he|she)\s+switched\s+off\s+the\s+([a-z]+)",c)
        if m:
            a,loc,pro,obj=m.groups()
            addfact(ir,"entered",a,loc); addfact(ir,"switched_off",pro,obj)

        # after audit
        if "after the audit" in cl and re.search(r"report was approved",cl):
            addfact(ir,"approval_after","report","audit")

        # key holding pronoun naive leaves "it"
        m=re.search(r"([A-Z][a-z]+)\s+is\s+holding\s+it",c)
        if m: addfact(ir,"holding",m.group(1),"it")

    return ir


def heuristic_parse_v2(text):
    ir=heuristic_parse(text)
    low=text.lower()
    # helpers for replacing facts
    def remove_fact(pred, args=None):
        new=[]
        for f in ir["facts"]:
            if f["pred"] != pred:
                new.append(f); continue
            if args is not None and tuple(f["args"]) != tuple(args):
                new.append(f)
        ir["facts"]=new

    # Very shallow discourse coreference: resolve she/he to nearest prior proper-name subject.
    # This is intentionally conservative and only when one salient named person precedes pronoun.
    names=re.findall(r"\b([A-Z][a-z]+)\b", text)
    # Remove temporal names/month/day not issue; find first likely person if pronoun.
    if re.search(r"\b(she|he)\b", low) and names:
        antecedent=slug(names[0])
        for f in ir["facts"]:
            f["args"]=[antecedent if x in {"she","he"} else x for x in f["args"]]

    # Pronoun it in holding/belonging: nearest prior definite common noun ("the key")
    m=re.search(r"the\s+([a-z]+)\s+belongs\s+to\s+[A-Z][a-z]+.*\b(?:it)\b",text,flags=re.I)
    if m:
        ant=slug(m.group(1))
        for f in ir["facts"]:
            f["args"]=[ant if x=="it" else x for x in f["args"]]

    # Relative "which is a TYPE" attaches to closest preceding NP token
    for m in re.finditer(r"\b([A-Za-z0-9]+),\s*which\s+is\s+an?\s+([A-Za-z_]+)",text,flags=re.I):
        ent,typ=m.groups()
        # drop erroneous type(which)
        ir["facts"]=[f for f in ir["facts"] if not (f["args"]==["which"])]
        addfact(ir,slug(typ),ent)

    # Passive: object was VERBed by Subject
    for m in re.finditer(r"(?:the\s+)?([a-zA-Z0-9_]+)\s+was\s+([a-z]+ed)\s+by\s+([A-Z][A-Za-z0-9_]*)",text):
        obj,v,subj=m.groups()
        pred={"approved":"approved","sent":"sent"}.get(v,slug(v))
        if pred=="sent":
            # without recipient cannot canonicalize ditransitive here
            pass
        else:
            addfact(ir,pred,subj,obj)

    # Negated "without being consumed by it" tied to nearest catalyst/reaction pattern
    m=re.search(r"catalyst\s+([A-Za-z0-9]+).*reaction\s+([A-Za-z0-9]+)\s+without\s+being\s+consumed\s+by\s+it",text,flags=re.I)
    if m:
        addfact(ir,"consumed_by",m.group(1),m.group(2),neg=True)

    # "then" ordering + coref
    m=re.search(r"([A-Z][a-z]+)\s+entered\s+the\s+([a-z]+),\s*then\s+(?:he|she)\s+switched\s+off\s+the\s+([a-z]+)",text)
    if m:
        who,loc,obj=m.groups()
        # ensure pronoun resolved
        ir["facts"]=[f for f in ir["facts"] if not (f["pred"]=="switched_off" and f["args"][0] in {"he","she"})]
        addfact(ir,"switched_off",who,obj)
        addfact(ir,"before_action","enter_"+slug(loc),"switch_off_"+slug(obj))

    # "because" simple causal event labels
    m=re.search(r"the\s+([a-z]+)\s+failed\s+because\s+the\s+([a-z]+)\s+lost\s+power",text,flags=re.I)
    if m:
        x,y=m.groups()
        addfact(ir,"caused",slug(y)+"_lost_power",slug(x)+"_failure")

    # Normalize succeed/succeeds inconsistency in unless constructions
    if "unless the backup succeeds" in low:
        # normalize negated succeed->succeeded
        for f in ir["facts"]:
            if f["pred"]=="succeed" and f.get("neg"):
                f["pred"]="succeeded"
        for r in ir["rules"]:
            for b in r["body"]:
                if b["pred"]=="succeeds":
                    b["pred"]="succeeded"

    # Belief / knowledge with a simple embedded proposition
    m=re.search(r"([A-Z][a-z]+)\s+believes\s+that\s+server\s+([A-Za-z0-9]+)\s+failed",text)
    if m:
        person,srv=m.groups()
        addfact(ir,"believes",person,slug(srv)+"_failed")
    m=re.search(r"([A-Z][a-z]+)\s+knows\s+that\s+server\s+([A-Za-z0-9]+)\s+failed",text)
    if m:
        person,srv=m.groups()
        addfact(ir,"knows",person,slug(srv)+"_failed")
        addfact(ir,"failed",srv)
    m=re.search(r"([A-Z][a-z]+)\s+does\s+not\s+believe\s+that\s+the\s+server\s+is\s+secure",text)
    if m:
        addfact(ir,"believes",m.group(1),"server_secure",neg=True)

    # Counterfactual if ... had ..., ... would have ...
    m=re.search(r"if\s+the\s+([a-z]+)\s+had\s+been\s+([a-z]+),\s*the\s+([a-z]+)\s+would\s+have\s+([a-z]+)",low)
    if m:
        s1,p1,s2,p2=map(slug,m.groups())
        addfact(ir,"counterfactual","c1")
        addfact(ir,"antecedent","c1",f"{s1}_{p1}")
        addfact(ir,"consequent","c1",f"{s2}_{p2}")

    # Conditional deontic while P: must not A -> prohibited A when P.
    m=re.search(r"(?:robot\s+)?([A-Za-z0-9]+)\s+must\s+not\s+([a-z]+)\s+while\s+the\s+([a-z]+)\s+is\s+([a-z]+)",text,flags=re.I)
    if m:
        subj,act,obj,state=map(slug,m.groups())
        ir["rules"].append(rule(atom(f"prohibited_{act}",subj),atom(f"{obj}_{state}")))
    if re.search(r"the\s+door\s+is\s+open",low):
        addfact(ir,"door_open")

    # Epistemic disjunction without choosing a branch.
    m=re.search(r"either\s+sensor\s+([A-Za-z])\s+or\s+sensor\s+([A-Za-z])\s+is\s+faulty.*does\s+not\s+say\s+which",text,flags=re.I)
    if m:
        a,b=map(slug,m.groups())
        addfact(ir,"alternative","g1")
        addfact(ir,"option","g1",f"sensor_{a}_faulty")
        addfact(ir,"option","g1",f"sensor_{b}_faulty")
        addfact(ir,"unresolved","g1")

    # PP attachment ambiguity: "X saw Y with Z"
    m=re.search(r"the\s+([a-z]+)\s+saw\s+the\s+([a-z]+)\s+with\s+the\s+([a-z]+)",low)
    if m:
        s,o,inst=map(slug,m.groups())
        addfact(ir,"saw",s,o)
        addfact(ir,"ambiguous_attachment","with_"+inst)

    # Simple conditional battery empty -> device shuts down; do not abduce.
    if re.search(r"if\s+the\s+battery\s+is\s+empty,\s*the\s+device\s+shuts\s+down",low):
        ir["rules"].append(rule(atom("shuts_down","device"),atom("battery_empty")))
    if re.search(r"the\s+device\s+shut\s+down",low):
        addfact(ir,"shuts_down","device")

    # Permission vs obligation
    if re.search(r"the\s+robot\s+is\s+allowed\s+to\s+move",low):
        addfact(ir,"permitted_move","robot")
    if re.search(r"it\s+is\s+not\s+required\s+to\s+move",low):
        addfact(ir,"required_move","robot",neg=True)

    # Deduplicate rules/facts
    uniq={}
    for f in ir["facts"]: uniq[atom_key(f)]=f
    ir["facts"]=list(uniq.values())
    # dedup rules
    seen=set(); rr=[]
    for r in ir["rules"]:
        k=(atom_key(r["head"]),tuple(atom_key(b) for b in r["body"]))
        if k not in seen:
            seen.add(k); rr.append(r)
    ir["rules"]=rr
    return ir
