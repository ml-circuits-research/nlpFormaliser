import { createOpenAICompatibleAdapter } from '../src/index.mjs';

export function adapterFromEnv(prefix, fallbackPrefix = null) {
  const get = k => process.env[`${prefix}_${k}`] ?? (fallbackPrefix ? process.env[`${fallbackPrefix}_${k}`] : undefined);
  const baseURL = get('BASE_URL');
  const model = get('MODEL');
  const apiKey = get('API_KEY') ?? '';
  if (!baseURL || !model) {
    throw new Error(`Missing ${prefix}_BASE_URL or ${prefix}_MODEL`);
  }
  return createOpenAICompatibleAdapter({ baseURL, model, apiKey, temperature: 0 });
}
