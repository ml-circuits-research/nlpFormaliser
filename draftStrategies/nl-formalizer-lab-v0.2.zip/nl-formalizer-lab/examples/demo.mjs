import fs from "node:fs/promises";
import {
  HeuristicStrategy,
  buildProtoIR,
  compileFormalModule,
  renderCNL
} from "../src/index.mjs";

const text = "Mira is a physicist. Mira owns a workstation.";
const proto = buildProtoIR(text);
const result = await new HeuristicStrategy().formalize(text, {proto});

console.log("=== NL ===");
console.log(text);
console.log("\n=== ProtoIR summary ===");
console.log({clauses: proto.clauses.length, mentions: proto.mentions.length, markers: proto.markers.length});
console.log("\n=== Formal IR ===");
console.log(JSON.stringify(result.ir, null, 2));
console.log("\n=== CNL ===");
console.log(renderCNL(result.ir));

const target = new URL("./generated/demo-formal.mjs", import.meta.url);
await fs.writeFile(target, compileFormalModule(result.ir));
console.log(`\nGenerated executable formal program: ${target.pathname}`);
