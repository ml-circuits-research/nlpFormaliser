# MJS v0.2 deterministic baseline

These results are produced by the new dependency-free MJS `heuristic` strategy, not by the old Python heuristic.

It is deliberately conservative and is **not** presented as a competitive formalizer. Its purpose is to provide a deterministic baseline/draft while the project compares direct LLM, ProtoIR-normalization and repair strategies.

Run:

```bash
node bin/eval.mjs --dataset benchmarks/pilot-heldout.json --strategy heuristic --quiet
```

The low held-out semantic score is useful: the benchmark still falsifies shallow lexical parsing rather than being tailored to the new library.
