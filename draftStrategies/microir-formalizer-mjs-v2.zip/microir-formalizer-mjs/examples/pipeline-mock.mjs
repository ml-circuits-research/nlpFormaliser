import { createPipeline } from '../src/index.mjs';

const formalizer = async () => '[$.plan(ravi,$.buy(ravi,laptop)),Q($.buy(ravi,laptop))]';
let n = 0;
const judge = async () => JSON.stringify(++n === 1
  ? {s:.75,eq:false,miss:['next month'],add:[],chg:[],amb:[]}
  : {s:1,eq:true,miss:[],add:[],chg:[],amb:[]});
const repairer = async () => '[$.time($.plan(ravi,$.buy(ravi,laptop)),next_month),Q($.buy(ravi,laptop))]';

const pipeline = createPipeline({ formalizer, judge, repairer, maxRepairs:1 });
console.log(JSON.stringify(await pipeline.run('Ravi plans to buy a laptop next month. Has he bought it?'), null, 2));
