import {makeIR, atom} from "../src/index.mjs";

// Example plugin loaded with:
// node bin/eval.mjs --dataset benchmarks/pilot-heldout.json --strategy-file examples/custom-strategy.mjs
export default {
  name: "example-custom-strategy",
  async formalize(text, {proto}) {
    // Replace with your own parser/model/compiler. This toy recognizes one sentence only.
    const ir = makeIR();
    const m = text.match(/^([A-Z][a-z]+) is a ([a-z]+)[.!?]?$/);
    if (m) ir.facts.push(atom(m[2], m[1]));
    return {ir, proto, artifacts:{}};
  }
};
