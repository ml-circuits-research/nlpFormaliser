# Pilot v1 evidence

This directory preserves the useful evidence from the first exploratory Python experiment that motivated the current MJS library.

The important result was not the 100% repair score (the same strong model helped design/annotate the benchmark and performed repair, so it is not independent evidence). The important negative result was that the frozen regex-like heuristic front end generalized poorly to paraphrases and contributed only a small fraction of the final repaired IR.

Reported pilot results:

- development heuristic v1: 63.4% overall / 54.7% semantic;
- development heuristic v2 after iteration: 100% (contaminated/overfit; not evidence);
- held-out frozen v2: 18.8% overall / 8.8% semantic;
- held-out after strong-model repair: 100% exploratory sanity check;
- unchanged final IR originating in the heuristic draft: 14.3%.

The current architecture therefore changes the role of deterministic analysis: `ProtoIR` is conservative and high-recall, while semantic canonicalization is a replaceable strategy.
