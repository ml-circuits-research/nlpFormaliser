import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { fromWire, toCNL } from '../src/index.mjs';
import { JUDGE_SYSTEM } from '../src/prompts.mjs';
import { adapterFromEnv } from './llm_env.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const rows=fs.readFileSync(path.join(here,'data/judge_pairs.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
const judge=adapterFromEnv('JUDGE','FORMALIZER');

function parse(s){
  s=String(s).trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'');
  try{return JSON.parse(s)}catch{}
  return JSON.parse(s.slice(s.indexOf('{'),s.lastIndexOf('}')+1));
}
async function score(text,wire){
  const cnl=toCNL(fromWire(wire));
  const raw=await judge({role:'judge',system:JUDGE_SYSTEM,user:`ORIGINAL:\n${text}\n\nCNL:\n${cnl}`});
  const j=parse(raw);
  return {score:Number(j.s??j.score??0),equivalent:Boolean(j.eq??j.equivalent),raw:j};
}

const results=[]; let wins=0, eqGood=0, rejectsBad=0;
for(const r of rows){
  const good=await score(r.text,r.goodWire);
  const bad=await score(r.text,r.badWire);
  const win=good.score>bad.score;
  if(win) wins++;
  if(good.equivalent) eqGood++;
  if(!bad.equivalent) rejectsBad++;
  results.push({id:r.id,expectedProblem:r.expectedProblem,good,bad,pairwiseWin:win});
  console.log(`${r.id}: good=${good.score.toFixed(3)} bad=${bad.score.toFixed(3)} ${win?'OK':'FAIL'}`);
}
const report={pairs:rows.length,pairwiseAccuracy:wins/rows.length,equivalentOnGood:eqGood/rows.length,rejectBad:rejectsBad/rows.length,results};
fs.writeFileSync(path.join(here,'..','reports','judge-eval.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({pairs:report.pairs,pairwiseAccuracy:report.pairwiseAccuracy,equivalentOnGood:report.equivalentOnGood,rejectBad:report.rejectBad},null,2));
