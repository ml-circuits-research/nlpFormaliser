import fs from 'node:fs';
import {
  formalizeConversation,
  buildJudgeBatches,
  auditConversation,
} from '../index.mjs';

const turns = JSON.parse(fs.readFileSync(new URL('./connected-chat.json', import.meta.url), 'utf8'));
const formalized = formalizeConversation(turns);
const batches = buildJudgeBatches(formalized, { policy: 'sampled', safeSampleRate: 0.20 });

console.log('=== FIRST FIVE CNL FORMALIZATIONS ===');
for (const t of formalized.turns.slice(0, 5)) {
  console.log('\n' + t.cnl);
}
console.log('\n=== SYMBOLIC AUDIT ===');
console.log(JSON.stringify(auditConversation(formalized), null, 2));
console.log('\n=== JUDGE BATCH SUMMARY ===');
console.log(JSON.stringify(batches.map(b => ({ batch_id: b.batch_id, items: b.items.length, turn_ids: b.items.map(x => x.turn_id) })), null, 2));
