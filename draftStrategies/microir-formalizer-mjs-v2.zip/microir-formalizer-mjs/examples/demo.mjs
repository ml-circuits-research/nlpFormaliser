import { $, A, I, U, E, Q, toWire, toCNL } from '../src/index.mjs';

const ir = [
  U(x => I(
    $.researcher(x),
    E(y => A($.paper(y), $.write(x,y)))
  )),
  Q($.researcher('alice'))
];

console.log('WIRE');
console.log(toWire(ir));
console.log('\nCNL');
console.log(toCNL(ir));
